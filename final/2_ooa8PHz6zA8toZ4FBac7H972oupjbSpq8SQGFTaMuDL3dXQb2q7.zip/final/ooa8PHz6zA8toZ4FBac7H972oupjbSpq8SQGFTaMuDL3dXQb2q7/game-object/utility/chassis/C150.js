import Chassis from '../chassis.js';

export default class C150 extends Chassis {
    constructor() {
        super(125);
    }
}
