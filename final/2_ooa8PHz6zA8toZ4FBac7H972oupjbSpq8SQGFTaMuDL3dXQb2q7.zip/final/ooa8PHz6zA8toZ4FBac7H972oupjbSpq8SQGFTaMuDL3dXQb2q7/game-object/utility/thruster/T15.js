import Thruster from '../thruster.js';

export default class T15 extends Thruster {
    constructor() {
        super(12);
    }
}
