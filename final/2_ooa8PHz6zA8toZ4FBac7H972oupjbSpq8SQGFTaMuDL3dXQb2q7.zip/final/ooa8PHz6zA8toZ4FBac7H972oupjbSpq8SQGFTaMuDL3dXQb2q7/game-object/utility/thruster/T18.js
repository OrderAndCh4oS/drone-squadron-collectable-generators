import Thruster from '../thruster.js';

export default class T18 extends Thruster {
    constructor() {
        super(15);
    }
}
