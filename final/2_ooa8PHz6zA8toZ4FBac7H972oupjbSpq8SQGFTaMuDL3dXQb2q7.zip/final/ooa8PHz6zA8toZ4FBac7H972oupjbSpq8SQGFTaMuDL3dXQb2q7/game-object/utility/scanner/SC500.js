import Scanner from '../scanner.js';

export default class SC500 extends Scanner {
    constructor() {
        super(500);
    }
}
