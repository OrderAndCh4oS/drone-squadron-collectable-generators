import Scanner from '../scanner.js';

export default class SC600 extends Scanner {
    constructor() {
        super(600);
    }
}
