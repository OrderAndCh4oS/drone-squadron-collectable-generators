import Scanner from '../scanner.js';

export default class SC300 extends Scanner {
    constructor() {
        super(300);
    }
}
