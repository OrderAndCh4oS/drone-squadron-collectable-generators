import Steering from '../steering.js';

export default class S12 extends Steering {
    constructor() {
        super(1);
    }
}
