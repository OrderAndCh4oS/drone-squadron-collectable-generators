import Thruster from '../thruster.js';

export default class T10 extends Thruster {
    constructor() {
        super(8);
    }
}
