import Thruster from '../thruster.js';

export default class T12 extends Thruster {
    constructor() {
        super(10);
    }
}
