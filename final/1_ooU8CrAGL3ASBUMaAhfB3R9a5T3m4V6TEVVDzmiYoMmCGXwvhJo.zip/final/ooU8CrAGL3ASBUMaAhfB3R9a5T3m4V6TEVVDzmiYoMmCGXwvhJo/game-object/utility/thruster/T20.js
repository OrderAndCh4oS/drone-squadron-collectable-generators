import Thruster from '../thruster.js';

export default class T20 extends Thruster {
    constructor() {
        super(17);
    }
}
