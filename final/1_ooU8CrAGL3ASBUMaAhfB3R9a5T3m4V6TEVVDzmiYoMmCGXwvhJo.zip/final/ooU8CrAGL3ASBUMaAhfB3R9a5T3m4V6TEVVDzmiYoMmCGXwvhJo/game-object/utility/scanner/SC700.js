import Scanner from '../scanner.js';

export default class SC700 extends Scanner {
    constructor() {
        super(700);
    }
}
