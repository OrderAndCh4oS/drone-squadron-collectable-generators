import Scanner from '../scanner.js';

export default class SC800 extends Scanner {
    constructor() {
        super(800);
    }
}
