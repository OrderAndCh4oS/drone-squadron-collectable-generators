import Scanner from '../scanner.js';

export default class SC400 extends Scanner {
    constructor() {
        super(400);
    }
}
