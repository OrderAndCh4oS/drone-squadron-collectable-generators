import Chassis from '../chassis.js';

export default class C175 extends Chassis {
    constructor() {
        super(150);
    }
}
