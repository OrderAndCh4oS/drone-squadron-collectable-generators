import Chassis from '../chassis.js';

export default class C125 extends Chassis {
    constructor() {
        super(100);
    }
}
