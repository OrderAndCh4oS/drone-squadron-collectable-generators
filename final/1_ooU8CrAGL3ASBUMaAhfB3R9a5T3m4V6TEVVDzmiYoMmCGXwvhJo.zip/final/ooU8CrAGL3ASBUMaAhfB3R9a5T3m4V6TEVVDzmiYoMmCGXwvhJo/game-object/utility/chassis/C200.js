import Chassis from '../chassis.js';

export default class C200 extends Chassis {
    constructor() {
        super(200);
    }
}
