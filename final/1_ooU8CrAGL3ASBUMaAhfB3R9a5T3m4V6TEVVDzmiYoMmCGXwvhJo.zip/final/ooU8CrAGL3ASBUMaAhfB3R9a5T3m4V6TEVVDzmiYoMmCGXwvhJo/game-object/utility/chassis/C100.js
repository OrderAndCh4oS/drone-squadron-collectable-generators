import Chassis from '../chassis.js';

export default class C100 extends Chassis {
    constructor() {
        super(75);
    }
}
