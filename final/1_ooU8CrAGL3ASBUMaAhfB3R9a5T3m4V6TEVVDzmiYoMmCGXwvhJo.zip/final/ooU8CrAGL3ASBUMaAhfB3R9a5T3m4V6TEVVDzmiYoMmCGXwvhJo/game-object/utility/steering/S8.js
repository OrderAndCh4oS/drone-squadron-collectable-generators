import Steering from '../steering.js';

export default class S8 extends Steering {
    constructor() {
        super(0.8);
    }
}
