import Steering from '../steering.js';

export default class S10 extends Steering {
    constructor() {
        super(0.9);
    }
}
